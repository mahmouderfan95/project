<p align="center" id="bas">
<a href="/noty/#/bakers" id="become-a-sponsor" class="bas">Become a Sponsor</a>
</p>

- [<div class="ps-icon ps-icon-arrow-right"></div> Home](/)
- [<div class="ps-icon ps-icon-download"></div> Installation](installation.md)
- [<div class="ps-icon ps-icon-row-setting"></div> Options & Defaults](options.md)
- [<div class="ps-icon ps-icon-apps"></div> Types & Layouts](types.md)
- [<div class="ps-icon ps-icon-wand"></div> Themes](themes.md)
- [<div class="ps-icon ps-icon-switch"></div> Show & Hide Animations](animations.md)
- [<div class="ps-icon ps-icon-ufo"></div> Web Push Notifications](push.md)
- [<div class="ps-icon ps-icon-headset"></div> Confirm Dialogs](confirm.md)
- [<div class="ps-icon ps-icon-puzzle"></div> API & Callbacks](api.md)
- [<div class="ps-icon ps-icon-laptop"></div> Browser Support](browsers.md)
- [<div class="ps-icon ps-icon-fried-egg"></div> Bakers](bakers.md)

